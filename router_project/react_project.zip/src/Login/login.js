import React from "react";


import { Outlet, Link } from "react-router-dom";


function Login() {
  return (
    <div>
      <div className=" continer mt-3 form">
        <form>
          <div className="input-container">
            <label>Username </label>
            <input type="text" name="uname" required />
            {/* {renderErrorMessage("uname")} */}
          </div>
          <div className="input-container">
            <label>Password </label>
            <input type="password" name="pass" required />
            {/* {renderErrorMessage("pass")} */}
          </div>
          <div className="button-container">
            <input type="submit" />
          </div>
        </form>
      </div>
      

      <>
        <nav>
          <ul>
            <li>
            
              <Link to="/header"> Demo</Link>
            </li>


          </ul>
        </nav>

        <Outlet />
      </>
    </div>
  )
}
export default Login;