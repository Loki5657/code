import React from "react";
import Header from "../Header/header";



function Technician(){
    return(
        <div>
              <Header/>
            this is technician page
        </div>
    )
}
export default Technician;