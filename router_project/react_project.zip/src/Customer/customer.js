import React from "react";
import Header from "../Header/header";


function Customer(){
    return(
        <div>
            <Header/>
            this is Customer page
        </div>
    )
}
export default Customer;